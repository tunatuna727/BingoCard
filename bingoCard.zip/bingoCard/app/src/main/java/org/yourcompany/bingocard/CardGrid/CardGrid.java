package org.yourcompany.bingocard.CardGrid;

import java.awt.GridLayout;

import javax.swing.JPanel;

import org.yourcompany.bingocard.CardGrid.CardGridCell.CardGridCell;

public class CardGrid extends JPanel {
    public static final int GRID_SIZE = 5;
    private final CardGridCell[] cells;

    public CardGridCell[] GetCells() {
        return cells;
    }

    public CardGrid() {
        setLayout(new GridLayout(GRID_SIZE, GRID_SIZE));
        cells = new CardGridCell[GRID_SIZE * GRID_SIZE];
        InitializeCells();
    }

    private void InitializeCells() {
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            cells[i] = new CardGridCell(i);
        }

        for (int col = 0; col < GRID_SIZE; col++) {
            for (int row = 0; row < GRID_SIZE; row++) {
                add(cells[row * GRID_SIZE + col]);
            }
        }
        UpdateUI();
    }

    public void UpdateUI() {
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            cells[i].UpdateUI();
        }
    }
    public void ResetUI() {
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            cells[i].ResetUI();
        }
    }
}
