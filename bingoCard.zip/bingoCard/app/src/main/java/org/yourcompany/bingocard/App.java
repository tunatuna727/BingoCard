package org.yourcompany.bingocard;

public class App {
    private BingoCard bingoCard;

    public static void main(String[] args) {
        App app = new App();
        app.Initialize();
    }

    public void Initialize() {
        bingoCard = new BingoCard();
        bingoCard.setVisible(true);
    }
}
