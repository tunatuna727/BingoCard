package org.yourcompany.bingocard.ui;


import javax.swing.*;
import java.awt.*;

public class RoundButton extends JButton {

    public RoundButton(String label) {
        super(label);
        setOpaque(false);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setFont(new Font("SansSerif", Font.BOLD, 16));
        setForeground(Color.WHITE);  // テキストカラー
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 背景色の設定
        if (getModel().isArmed()) {
            g2.setColor(new Color(200, 200, 200));  // 押された時の色
        } else {
            g2.setColor(getBackground());  // 通常の背景色
        }
        // ボタンの形を丸くする
        int diameter = Math.min(getWidth(), getHeight());  // ボタンを正方形に保つ
        g2.fillOval(0, 0, diameter, diameter);  // 丸い形で描画

        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        size.width = size.height = Math.max(size.width, size.height);  // ボタンを正方形に保つ
        return size;
    }

    @Override
    protected void paintBorder(Graphics g) {
        // 枠線を描画しない
    }
}
