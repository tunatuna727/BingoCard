package org.yourcompany.bingocard;

import java.util.Arrays;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.yourcompany.bingocard.CardGrid.CardGrid;
import org.yourcompany.bingocard.Data.BingoData;
import org.yourcompany.bingocard.ResetButton.ResetButton;

public class BingoCard extends JFrame {
    private final int GRID_SIZE = CardGrid.GRID_SIZE;
    private CardGrid cardGrid;
    private ResetButton resetButton;

    public BingoCard() {
        BingoData.getInstance().InitializeData();
        InitializeUI();
    }

    private void InitializeUI() {
        // コンポーネントの初期化
        cardGrid = new CardGrid();
        cardGrid.UpdateUI();
        resetButton = new ResetButton();
        
        // リセットボタンのアクションリスナー
        resetButton.addActionListener(e -> {
            BingoData.getInstance().InitializeData();
            cardGrid.ResetUI();
        });

        // セルのアクションリスナー
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            final int index = i;
            cardGrid.GetCells()[index].addActionListener(e -> OnClickCell(index));
        }

        setTitle("Bingo Card");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 550);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(cardGrid);
        resetButton.setAlignmentX(CENTER_ALIGNMENT);
        add(resetButton);

        cardGrid.ResetUI();
    }

    private void OnClickCell(int index) {
        BingoData.getInstance().GetSelectList()[index] = 1;
        
        boolean[] bingoAndReach = IsNewBingoAndReach();

        System.out.println("selectList: " + Arrays.toString(BingoData.getInstance().GetSelectList()));
        System.out.println("reachList: " + Arrays.toString(BingoData.getInstance().GetReachList()));
        System.out.println("bingoList: " + Arrays.toString(BingoData.getInstance().GetBingoList()));
        System.out.println();

        cardGrid.UpdateUI();

        if (bingoAndReach[0]) {
            ShowMessage("ビンゴです！");
        } else if (bingoAndReach[1]) {
            ShowMessage("リーチです！");
        }

    }

    private void ShowMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "お知らせ", JOptionPane.INFORMATION_MESSAGE);
    }

    private boolean[] IsNewBingoAndReach() {
        boolean isNewBingo = false;
        boolean isNewReach = false;
        int[] prevBingoList = BingoData.getInstance().GetBingoList().clone();
        int[] prevReachList = BingoData.getInstance().GetReachList().clone();
        CheckStatus();
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            if (prevBingoList[i] != BingoData.getInstance().GetBingoList()[i]) {
                isNewBingo = true;
            }
            if (prevReachList[i] != BingoData.getInstance().GetReachList()[i]) {
                isNewReach = true;
            }
        }
        return new boolean[] { isNewBingo, isNewReach };
    }

    private void CheckStatus() {
        CheckColumnStatus();
        CheckRowStatus();
        CheckCrossStatus();
    }

    /// <summary>
    /// 列のビンゴチェック
    /// </summary>
    private void CheckColumnStatus() {
        int[] sumList = new int[GRID_SIZE];
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            sumList[i % GRID_SIZE] += BingoData.getInstance().GetSelectList()[i];
        }
        for (int i = 0; i < GRID_SIZE; i++) {
            if (sumList[i] == GRID_SIZE - 1) {
                // この行はリーチ
                for (int j = 0; j < GRID_SIZE; j++) {
                    BingoData.getInstance().GetReachList()[i + j * GRID_SIZE] = 1;
                }
            }
            if (sumList[i] == GRID_SIZE) {
                // この行はビンゴ
                for (int j = 0; j < GRID_SIZE; j++) {
                    BingoData.getInstance().GetBingoList()[i + j * GRID_SIZE] = 1;
                }
            }
        }
    }

    /// <summary>
    /// 行のビンゴチェック
    /// </summary>
    private void CheckRowStatus() {
        int[] sumList = new int[GRID_SIZE];
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            sumList[i / GRID_SIZE] += BingoData.getInstance().GetSelectList()[i];
        }
        for (int i = 0; i < GRID_SIZE; i++) {
            if (sumList[i] == GRID_SIZE - 1) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    BingoData.getInstance().GetReachList()[i * GRID_SIZE + j] = 1;
                }
            }
            if (sumList[i] == GRID_SIZE) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    BingoData.getInstance().GetBingoList()[i * GRID_SIZE + j] = 1;
                }
            }
        }
    }

    /// <summary>
    /// 斜めのビンゴチェック
    /// </summary>
    private void CheckCrossStatus() {
        int[] sumList = new int[2];
        for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
            if (i % (GRID_SIZE - 1) == 0 && i != 0 && i != GRID_SIZE * GRID_SIZE - 1) {
                sumList[0] += BingoData.getInstance().GetSelectList()[i];
            }
            if (i % (GRID_SIZE + 1) == 0) {
                sumList[1] += BingoData.getInstance().GetSelectList()[i];
            }
        }
        for (int i = 0; i < 2; i++) {
            if (sumList[i] == GRID_SIZE - 1) {
                // この斜めはリーチ
                if (i == 0) {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        BingoData.getInstance().GetReachList()[j * (GRID_SIZE - 1) + GRID_SIZE - 1] = 1;
                    }
                } else {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        BingoData.getInstance().GetReachList()[j * (GRID_SIZE + 1)] = 1;
                    }
                }
            }
            if (sumList[i] == GRID_SIZE) {
                if (i == 0) {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        BingoData.getInstance().GetBingoList()[j * (GRID_SIZE - 1) + GRID_SIZE - 1] = 1;
                    }
                }
                if (i == 1) {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        BingoData.getInstance().GetBingoList()[j * (GRID_SIZE + 1)] = 1;
                    }
                }
            }
        }
    }
}
