package org.yourcompany.bingocard.Data;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class BingoData {
    private static BingoData instance; // シングルトンインスタンス
    private int[] numberList;
    private int[] reachList;
    private int[] selectList;
    private int[] bingoList;

    private HashSet<String> bingoSet;

    // プライベートコンストラクタ
    private BingoData() {
        bingoSet = new HashSet<>();
        GenerateNumberList();
        InitializeReachList();
        InitializeSelectList();
        InitializeBingoList();
    }

    // シングルトンインスタンスを取得するメソッド
    public static BingoData getInstance() {
        if (instance == null) {
            instance = new BingoData();
        }
        return instance;
    }

    public int[] GetNumberList() {
        return numberList;
    }

    public int[] GetReachList() {
        return reachList;
    }

    public int[] GetSelectList() {
        return selectList;
    }

    public int[] GetBingoList() {
        return bingoList;
    }

    public void InitializeData() {
        GenerateNumberList();
        InitializeReachList();
        InitializeSelectList();
        InitializeBingoList();
    }

    private void GenerateNumberList() {
        do {
            numberList = new int[25];
            for (int i = 0; i < 5; i++) {
                List<Integer> randomNumbers = GetRandomNumbers(15 * i + 1, 15 * (i + 1), 15);
                for (int j = 0; j < 5; j++) {
                    numberList[5 * i + j] = randomNumbers.get(j);
                }
            }
            // 13番目は0にする
            numberList[12] = 0;
        } while (!bingoSet.add(getMD5Hash(numberList)));
    }

    private void InitializeReachList() {
        // 全て0にする
        reachList = new int[25];
        for (int i = 0; i < 25; i++) {
            reachList[i] = 0;
        }
    }

    private void InitializeSelectList() {
        selectList = new int[25];
        for (int i = 0; i < 25; i++) {
            selectList[i] = 0;
        }

        // 13番目は1にする
        selectList[12] = 1;
    }

    private void InitializeBingoList() {
        bingoList = new int[25];
        for (int i = 0; i < 25; i++) {
            bingoList[i] = 0;
        }
    }

    private List<Integer> GetRandomNumbers(int min, int max, int count) {
        List<Integer> numbers = new ArrayList<>();
        for (int i = min; i <= max; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);
        return numbers.subList(0, count);
    }

    private String getMD5Hash(int[] numbers) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            for (int number : numbers) {
                md.update((byte) number);
            }
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            System.out.println("hash: " + sb.toString());
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

}
