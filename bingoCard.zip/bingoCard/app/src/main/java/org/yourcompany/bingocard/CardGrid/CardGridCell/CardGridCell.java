package org.yourcompany.bingocard.CardGrid.CardGridCell;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JButton;

import org.yourcompany.bingocard.Data.BingoData;

public class CardGridCell extends JButton {
    private final int index;
    private final Color textPink = new Color(255, 130, 250);
    private final Color backgroundPink = new Color(255, 229, 253);

    public CardGridCell(int index) {
        this.index = index;
        Initialize();
    }

    private void Initialize() {
        setOpaque(false);
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFont(new Font("SansSerif", Font.BOLD, 16));
        UpdateUI();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 背景色の設定
        if (getModel().isArmed()) {
            g2.setColor(getBackground());  // 押された時の色
        } else {
            g2.setColor(getBackground());  // 通常の背景色
        }
        // ボタンの形を丸くする
        int diameter = Math.min(getWidth(), getHeight());  // ボタンを正方形に保つ
        g2.fillOval(0, 0, diameter, diameter);  // 丸い形で描画

        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        size.width = size.height = Math.max(size.width, size.height);  // ボタンを正方形に保つ
        return size;
    }

    @Override
    protected void paintBorder(Graphics g) {
        // 枠線を描画しない
    }

    public void UpdateUI() {
        SetText();
        SetIsSelected();
        SetReached();
        SetBingo();
    }

    public void ResetUI() {
        SetText();
        setBorderPainted(false);
        setBackground(Color.WHITE);
        setForeground(Color.BLACK);
        SetIsSelected();
    }

    private void SetText() {
        if (BingoData.getInstance().GetNumberList()[index] == 0) {
            setText("Free");
        } else {
            setText(String.valueOf(BingoData.getInstance().GetNumberList()[index]));
        }
    }

    private void SetIsSelected() {
        if (BingoData.getInstance().GetSelectList()[index] == 1) {
            setForeground(textPink);
            repaint();
        }
    }

    private void SetReached() {
        if (BingoData.getInstance().GetReachList()[index] == 1) {
            // ボーダーを表示する
            setBackground(backgroundPink);
            repaint();
        }
    }

    private void SetBingo() {
        if (BingoData.getInstance().GetBingoList()[index] == 1) {
            setBackground(textPink);
            setForeground(Color.WHITE);
            repaint();
        }
    }
}
