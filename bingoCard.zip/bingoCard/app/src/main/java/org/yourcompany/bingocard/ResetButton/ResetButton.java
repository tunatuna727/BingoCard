package org.yourcompany.bingocard.ResetButton;

import javax.swing.JButton;

public class ResetButton extends JButton {
    public ResetButton() {
        setText("RESET");  
        setFocusPainted(false);  
    }
}